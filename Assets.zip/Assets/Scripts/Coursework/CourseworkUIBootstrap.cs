using System;
using UnityEngine;
using UnityEngine.UI;

namespace Coursework2D
{
    // Быстрый тестовый интерфейс uGUI. Для полноценного редактора можно заменить собственным Canvas.
    public class CourseworkUIBootstrap : MonoBehaviour
    {
        public LevelEditorController editor;
        public LevelPlayabilityChecker checker;
        public ConcurrencyBenchmark benchmark;
        private Text status;
        private InputField nameInput;
        private InputField searchInput;
        private InputField difficultyInput;
        private Text listText;

        private void Start()
        {
            // Исправлено: FindObjectOfType заменен на FindFirstObjectByType
            if (editor == null) editor = FindFirstObjectByType<LevelEditorController>();
            if (checker == null) checker = FindFirstObjectByType<LevelPlayabilityChecker>();
            if (benchmark == null) benchmark = FindFirstObjectByType<ConcurrencyBenchmark>();
            BuildUI();
            if (editor != null) { editor.Message += SetStatus; editor.DataChanged += RefreshList; RefreshList(); }
            if (checker != null) checker.ResultReceived += r => SetStatus($"{r.levelName}: {(r.playable ? "проходим" : "ошибка")} — {r.message}");
        }

        private void BuildUI()
        {
            // Исправлено: FindObjectOfType заменен на FindFirstObjectByType
            if (FindFirstObjectByType<UnityEngine.EventSystems.EventSystem>() == null)
                new GameObject("EventSystem", typeof(UnityEngine.EventSystems.EventSystem), typeof(UnityEngine.EventSystems.StandaloneInputModule));
            var canvasObject = new GameObject("CourseworkRuntimeCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>(); canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasObject.GetComponent<CanvasScaler>(); scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize; scaler.referenceResolution = new Vector2(1280, 720);
            var panel = MakeRect("Panel", canvas.transform, new Vector2(0, 0), new Vector2(0.48f, 1), new Vector2(0, 0), new Vector2(0.48f, 1));
            panel.gameObject.AddComponent<Image>().color = new Color(0.08f, 0.09f, 0.12f, 0.92f);
            nameInput = MakeInput(panel, "Название уровня", new Vector2(0.04f, 0.88f), new Vector2(0.58f, 0.96f));
            difficultyInput = MakeInput(panel, "Сложность 1-5", new Vector2(0.62f, 0.88f), new Vector2(0.96f, 0.96f));
            MakeButton(panel, "Создать уровень", new Vector2(0.04f, 0.79f), new Vector2(0.48f, 0.86f), CreateLevel);
            MakeButton(panel, "Удалить выбранный", new Vector2(0.52f, 0.79f), new Vector2(0.96f, 0.86f), DeleteSelected);
            MakeButton(panel, "Сохранить JSON", new Vector2(0.04f, 0.70f), new Vector2(0.48f, 0.77f), () => editor?.Save());
            MakeButton(panel, "Загрузить JSON", new Vector2(0.52f, 0.70f), new Vector2(0.96f, 0.77f), () => editor?.Reload());
            searchInput = MakeInput(panel, "Поиск по названию", new Vector2(0.04f, 0.61f), new Vector2(0.96f, 0.68f));
            MakeButton(panel, "Найти", new Vector2(0.04f, 0.52f), new Vector2(0.48f, 0.59f), SearchLevels);
            MakeButton(panel, "Сортировать по сложности", new Vector2(0.52f, 0.52f), new Vector2(0.96f, 0.59f), () => ShowLevels(editor?.SortByDifficulty()));
            MakeButton(panel, "Проверить проходимость", new Vector2(0.04f, 0.43f), new Vector2(0.48f, 0.50f), () => { if (editor != null && checker != null) checker.CheckMany(editor.Data.levels); });
            MakeButton(panel, "Тест 10 000+ объектов", new Vector2(0.52f, 0.43f), new Vector2(0.96f, 0.50f), () => benchmark?.RunBenchmark());
            listText = MakeText(panel, "Список уровней", new Vector2(0.04f, 0.14f), new Vector2(0.96f, 0.40f), 16);
            status = MakeText(panel, "Готово", new Vector2(0.04f, 0.02f), new Vector2(0.96f, 0.12f), 13);
            SetStatus("Редактор запущен. Файлы сохраняются в persistentDataPath.");
        }

        private void CreateLevel()
        {
            if (editor == null) return;
            int d = int.TryParse(difficultyInput.text, out int parsed) ? parsed : 1;
            editor.CreateLevel(nameInput.text, d, 20, 12);
        }
        private void DeleteSelected() { if (editor != null) editor.DeleteLevel(editor.SelectedIndex); }
        private void SearchLevels() { if (editor != null) ShowLevels(editor.Search(searchInput.text)); }
        private void ShowLevels(System.Collections.Generic.IReadOnlyList<Level> levels)
        {
            if (listText == null) return;
            if (levels == null) { listText.text = "Нет данных"; return; }
            listText.text = "";
            for (int i = 0; i < levels.Count; i++) listText.text += $"{i + 1}. {levels[i].name} | сложность {levels[i].difficulty} | объектов {levels[i].objectCount}\n";
        }
        private void RefreshList() { if (editor != null) ShowLevels(editor.Data.levels); }
        private void SetStatus(string message) { if (status != null) status.text = message; }

        private static RectTransform MakeRect(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            var go = new GameObject(name, typeof(RectTransform)); go.transform.SetParent(parent, false);
            var r = go.GetComponent<RectTransform>(); r.anchorMin = anchorMin; r.anchorMax = anchorMax; r.offsetMin = offsetMin; r.offsetMax = offsetMax; return r;
        }
        private static Text MakeText(Transform parent, string text, Vector2 min, Vector2 max, int size)
        {
            var r = MakeRect("Text", parent, min, max, Vector2.zero, Vector2.zero); var t = r.gameObject.AddComponent<Text>();
            t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); t.fontSize = size; t.color = Color.white; t.alignment = TextAnchor.MiddleLeft; t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Overflow; return t;
        }
        private static InputField MakeInput(Transform parent, string placeholder, Vector2 min, Vector2 max)
        {
            var r = MakeRect("Input_" + placeholder, parent, min, max, Vector2.zero, Vector2.zero); r.gameObject.AddComponent<Image>().color = Color.white;
            var input = r.gameObject.AddComponent<InputField>();
            var text = MakeText(r, "", new Vector2(0.03f, 0.05f), new Vector2(0.97f, 0.95f), 14); text.color = Color.black; input.textComponent = text;
            var p = MakeText(r, placeholder, new Vector2(0.03f, 0.05f), new Vector2(0.97f, 0.95f), 14); p.color = Color.gray; input.placeholder = p; return input;
        }
        private static void MakeButton(Transform parent, string label, Vector2 min, Vector2 max, Action action)
        {
            var r = MakeRect("Button_" + label, parent, min, max, Vector2.zero, Vector2.zero); r.gameObject.AddComponent<Image>().color = new Color(0.15f, 0.35f, 0.55f);
            var b = r.gameObject.AddComponent<Button>(); MakeText(r, label, new Vector2(0.03f, 0.03f), new Vector2(0.97f, 0.97f), 13).alignment = TextAnchor.MiddleCenter;
            b.onClick.AddListener(() => action?.Invoke());
        }
    }
}