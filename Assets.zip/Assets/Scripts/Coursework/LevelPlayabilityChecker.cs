using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using UnityEngine;

namespace Coursework2D
{
    public sealed class LevelCheckResult
    {
        public string levelName;
        public bool playable;
        public string message;
        public long elapsedMilliseconds;
    }

    // Все вычисления в Task.Run работают только с обычными данными, не с Unity API.
    public class LevelPlayabilityChecker : MonoBehaviour
    {
        public int Completed { get; private set; }
        public int Total { get; private set; }
        public float Progress => Total == 0 ? 0f : (float)Completed / Total;
        public bool IsRunning { get; private set; }
        public event Action<LevelCheckResult> ResultReceived;
        public event Action<float> ProgressChanged;

        private readonly ConcurrentQueue<LevelCheckResult> results = new ConcurrentQueue<LevelCheckResult>();
        private readonly object progressLock = new object();
        private int completedWorker;

        public void CheckMany(IList<Level> levels)
        {
            if (IsRunning) { FileLogger.Write("Проверка уже выполняется."); return; }
            if (levels == null) throw new ArgumentNullException(nameof(levels));
            var snapshot = new List<Level>(levels);
            Total = snapshot.Count; Completed = 0; completedWorker = 0; IsRunning = true;
            if (Total == 0) { IsRunning = false; ProgressChanged?.Invoke(1f); return; }
            Task.Run(() => Parallel.ForEach(snapshot, level =>
            {
                var sw = Stopwatch.StartNew();
                bool ok = IsPlayable(level, out string message);
                sw.Stop();
                results.Enqueue(new LevelCheckResult { levelName = level?.name ?? "(null)", playable = ok, message = message, elapsedMilliseconds = sw.ElapsedMilliseconds });
                lock (progressLock) completedWorker++;
            })).ContinueWith(t =>
            {
                if (t.IsFaulted) FileLogger.Write("Ошибка параллельной проверки.", t.Exception);
                results.Enqueue(new LevelCheckResult { levelName = "__COMPLETE__", playable = !t.IsFaulted, message = "complete" });
            });
        }

        private void Update()
        {
            while (results.TryDequeue(out var result))
            {
                if (result.levelName == "__COMPLETE__") { IsRunning = false; continue; }
                Completed++;
                ResultReceived?.Invoke(result);
                ProgressChanged?.Invoke(Progress);
            }
            if (Total > 0 && !IsRunning && Completed >= Total) ProgressChanged?.Invoke(1f);
        }

        public static bool IsPlayable(Level level, out string message)
        {
            var errors = LevelValidationService.Validate(level);
            if (errors.Count > 0) { message = string.Join("; ", errors); return false; }
            int w = level.gridWidth, h = level.gridHeight;
            var blocked = new bool[w, h];
            foreach (var o in level.objects)
                if (o != null && (o.type == LevelObjectType.Hazard)) blocked[o.position.x, o.position.y] = true;
            var visited = new bool[w, h];
            var q = new Queue<Vector2Int>();
            q.Enqueue(new Vector2Int(level.start.x, level.start.y));
            visited[level.start.x, level.start.y] = true;
            int[] dx = { 1, -1, 0, 0 }, dy = { 0, 0, 1, -1 };
            while (q.Count > 0)
            {
                var p = q.Dequeue();
                if (p.x == level.finish.x && p.y == level.finish.y) { message = "Путь найден."; return true; }
                for (int i = 0; i < 4; i++)
                {
                    int nx = p.x + dx[i], ny = p.y + dy[i];
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h || visited[nx, ny] || blocked[nx, ny]) continue;
                    visited[nx, ny] = true; q.Enqueue(new Vector2Int(nx, ny));
                }
            }
            message = "Путь от старта к финишу не найден."; return false;
        }
    }
}
